﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

namespace Ati7FPFutebol
{
    public partial class Inserir : Page
    {
        protected void b_inserir_Click(object sender, EventArgs e)
        {
            string connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Ati7FPFutebol\App_Data\dbFPF.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connetionString))
            {
                con.Open();

                string sql = "INSERT INTO tab_jogador (N_federacao, Nome, Email, Data_Nasc, Morada, Equipa_Sigla, posicao_id) " +
                             "VALUES (@N_federacao, @Nome, @Email, @Data_Nasc, @Morada, @Equipa_Sigla, @posicao_id)";

                using (SqlCommand command = new SqlCommand(sql, con))
                {
                    
                    command.Parameters.AddWithValue("@N_federacao", int.Parse(txt_n_federacao.Text));
                    command.Parameters.AddWithValue("@Nome", txt_nome.Text);
                    command.Parameters.AddWithValue("@Email", txt_email.Text);
                    command.Parameters.AddWithValue("@Data_Nasc", DateTime.Parse(txt_data_nasc.Text));
                    command.Parameters.AddWithValue("@Morada", txt_morada.Text);
                    command.Parameters.AddWithValue("@Equipa_Sigla", txt_equipa_sigla.Text);
                    command.Parameters.AddWithValue("@posicao_id", int.Parse(txt_posicao_id.Text));

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        ltInserirOutput.Text = "Jogador inserido com sucesso";
                    }
                    else
                    {
                        ltInserirOutput.Text = "Erro ao inserir jogador";
                    }
                }
            }

            LimparCampos();
        }

        private void LimparCampos()
        {
            
            txt_n_federacao.Text = "";
            txt_nome.Text = "";
            txt_email.Text = "";
            txt_data_nasc.Text = "";
            txt_morada.Text = "";
            txt_equipa_sigla.Text = "";
            txt_posicao_id.Text = "";
        }
    }
}
